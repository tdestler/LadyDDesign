﻿$(document).ready(function () {
    $('#imgZoom').width(200);
    $('#imgZoom').mouseover(function () {
        $(this).css("cursor", "pointer");
        $(this).animate({ width: "500px" }, 'slow');
    });

    $('#imgZoom').mouseout(function () {
        $(this).animate({ width: "200px" }, 'slow');
    });
});