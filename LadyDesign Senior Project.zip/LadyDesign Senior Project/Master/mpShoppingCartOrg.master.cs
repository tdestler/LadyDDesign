﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Master_mpShoppingCartOrg : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["Seasonal"] = clsDataLayer.GetConfig();

        String season = Session["Seasonal"].ToString();

        if (season == "Winter")
        {


            selectCSS.Href = "../CSS/WinterForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
        }

        else if (season == "Spring")
        {


            selectCSS.Href = "../CSS/SpringForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
        }

        else if (season == "Summer")
        {


            selectCSS.Href = "../CSS/SummerForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
        }

        else
        {


            selectCSS.Href = "../CSS/AutumnForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
        }
    }
}
