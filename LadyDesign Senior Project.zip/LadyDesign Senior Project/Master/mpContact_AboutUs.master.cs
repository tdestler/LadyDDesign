﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Master_mpContact_AboutUs : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            clsCartItemList cart = clsCartItemList.GetCart();
            int numCartItem = cart.Count;

            try
            {
                lblCart.Text = numCartItem.ToString();
            }
            catch
            {
                lblCart.Text = "0";
            }

            
        }
        

        Session["Seasonal"] = clsDataLayer.GetConfig();

        String season = Session["Seasonal"].ToString();

        if (season == "Winter")
        {


            selectCSS.Href = "../CSS/WinterForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
            LinkButton1.Attributes.CssStyle.Add("Color", "#A9F5F2");
            
        }

        else if (season == "Spring")
        {


            selectCSS.Href = "../CSS/SpringForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
            LinkButton1.Attributes.CssStyle.Add("Color", "#A9F5F2");
        }

        else if (season == "Summer")
        {


            selectCSS.Href = "../CSS/SummerForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
            LinkButton1.Attributes.CssStyle.Add("Color", "#A9F5F2");
        }

        else
        {


            selectCSS.Href = "../CSS/AutumnForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
            LinkButton1.Attributes.CssStyle.Add("Color", "#A9F5F2");
        }
    }


    protected void btnEmailSub_Click(object sender, EventArgs e)
    {
        if (txtEmail.Text.Length == 0)
        {
            RequiredFieldValidator1.Text = "Please Enter an Email Address";
        }
        else
        {
            clsDataLayer.SaveEmail(txtEmail.Text);
        }



    }
}
