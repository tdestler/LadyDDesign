﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;




public partial class Master_mpOrderForms : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            clsCartItemList cart = clsCartItemList.GetCart();
            int numCartItem = cart.Count;

            try
            {
                lblCart.Text = numCartItem.ToString();
            }
            catch
            {
                lblCart.Text = "0";
            }


        }

        Menu1.Attributes.CssStyle.Add("border-style","solid");

        form2.Attributes.CssStyle.Add("height", "900px");

        Session["Seasonal"] = clsDataLayer.GetConfig();

        String season = Session["Seasonal"].ToString();

        if (season == "Winter")
        {


            selectCSS.Href = "../CSS/WinterForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
        }

        else if (season == "Spring")
        {


            selectCSS.Href = "../CSS/SpringForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
           
        }

        else if (season == "Summer")
        {


            selectCSS.Href = "../CSS/SummerForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
        }

        else
        {


            selectCSS.Href = "../CSS/AutumnForm.css";
            selectCSS.Attributes["rel"] = "stylesheet";
            selectCSS.Attributes["type"] = "text/css";
            selectCSS.Attributes["media"] = "all";
            Page.Header.Controls.Add(selectCSS);
        }



    }


}
